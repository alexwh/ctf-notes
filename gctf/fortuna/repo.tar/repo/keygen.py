"""
Tool for generating self-signed SSL certificates and keys.
"""

import hashlib
import os
import sys
import time
from Crypto.PublicKey import pubkey
from Crypto.PublicKey import RSA
from Crypto.Random.Fortuna import FortunaGenerator
from Crypto.Util import number
from OpenSSL import crypto as openssl


class SecureRand(object):
    """Implement a better PRNG by wrapping Fortuna."""

    def __init__(self, seed=None):
        self.state = hashlib.sha256(seed or self._newSeed()).digest()
        self.prng = FortunaGenerator.AESGenerator()
        self.prng.reseed(self.state)

    def _newSeed(self):
        return (os.name + str(int(time.time())))

    def read(self, n):
        return self.prng.pseudo_random_data(n)


def GenerateReallyStrongPrime(nbits, e=65537, randfunc=None):
    return number.getStrongPrime(nbits, e=e, false_positive_prob=1e-80,
            randfunc=randfunc)


def GenerateRSAKey(nbits, rand):
    rsa = pubkey.pubkey()
    rsa.e = 65537L
    rsa.p = GenerateReallyStrongPrime(nbits/2, e=rsa.e, randfunc=rand.read)
    rsa.q = GenerateReallyStrongPrime(nbits/2, e=rsa.e, randfunc=rand.read)
    rsa.u = pubkey.inverse(rsa.p, rsa.q)
    rsa.n = rsa.p*rsa.q
    rsa.d = pubkey.inverse(rsa.e, (rsa.p-1)*(rsa.q-1))
    return RSA.construct((rsa.n, rsa.e, rsa.d, rsa.p, rsa.q, rsa.u))


def SignKey(key, hostname):
    """Returns the signed key as a PEM-encoded string."""
    cert = openssl.X509()
    cert.get_subject().C = "US"
    cert.get_subject().ST = "CA"
    cert.get_subject().L = "Mountain View"
    cert.get_subject().O = "Capture the Flag"
    cert.get_subject().OU = "Capture the Flag"
    cert.get_subject().CN = hostname
    cert.set_serial_number(1)
    cert.gmtime_adj_notBefore(0)
    cert.gmtime_adj_notAfter(365*24*60*60)  # 1 year
    cert.set_issuer(cert.get_subject())
    pkey = openssl.load_privatekey(openssl.FILETYPE_PEM, key.exportKey())
    cert.set_pubkey(pkey)
    cert.sign(pkey, "sha256")
    return openssl.dump_certificate(openssl.FILETYPE_PEM, cert)


def main(argv):
    if len(argv) != 2:
        return usage(argv)
    rand = SecureRand()
    key = GenerateRSAKey(4096, rand)
    cert = SignKey(key, argv[1])
    keyfile = "%s.key" % argv[1]
    open(keyfile, "w").write(key.exportKey())
    print "Wrote key to %s" % keyfile
    certfile = "%s.crt" % argv[1]
    open(certfile, "w").write(cert)
    print "Wrote cert to %s" % certfile
    return 0


def usage(argv):
    print "Usage: %s <hostname>" % argv[0]
    return 1


if __name__ == "__main__":
    main(sys.argv)
